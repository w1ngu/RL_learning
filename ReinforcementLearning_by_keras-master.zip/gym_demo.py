import numpy as np
import time
import sys
if sys.version_info.major == 2:
    import Tkinter as tk
else:
    import tkinter as tk

UNIT = 40   # pixels
MAZE_H = 4  # grid height       #迷宫大小 高
MAZE_W = 4  # grid width        #迷宫大小 宽

import gym
from  RL_brain import DQN

env = gym.make('CartPole-v0')
print(env.action_space)
print(env.observation_space.shape[0])
print(env.observation_space.high)
print(env.observation_space.low)

RL = DQN(n_actions=env.action_space.n,
         n_features=env.observation_space.shape[0],
         learning_rate=0.01,
         reward_decay=0.9,
         e_greedy=0.9,
         replace_target_iter=100,
         memory_size=2000,
         e_greedy_increment=0.001
         )

total_step = 0

for i in range(1000):
    observation = env.reset()

    while True:
        env.render()

        action = RL.choose_action(observation)


        observation_, reward, done, info = env.step(action)  # 根据下一个动作得到 下一个观测值， 奖励， 是否结束标志

        x,x_dot,theta, theta_dot = observation_

        r1 = (env.x_threshold - abs(x))/env.x_threshold - 0.8
        r2 = (env.theta_threshold_radians - abs(theta))/env.theta_threshold_radians - 0.8
        reward = r1+r2

        RL.store_transition(observation, action, reward, observation_)  # 存储记忆   观测值， 动作， 得到的奖励， 下一个观测值


        if total_step>1000:  # 如果超过200 步 是5的倍数
            RL.learn()  # 学习



        # swap observation
        observation = observation_  # 更新观测值


        # break while loop when end of this episode
        if done:  # 结束标志
            break
        total_step += 1  # 步数累加

        print(total_step)